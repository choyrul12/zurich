jQuery(document).ready(function($){
	$('.menu-btn, .menu-close').click(function(){
		$('body').toggleClass('menu-open');
	})
})