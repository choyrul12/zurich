<?php
$login_screen_width = "100%";   
$login_screen_height = "";




?>
