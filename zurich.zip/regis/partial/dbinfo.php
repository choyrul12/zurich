<?php
$db['host']     = 'localhost';   //Your database host, I.E. localhost
$db['username'] = 'riseofth_zurich';        //Your database username
$db['password'] = 'yD6-zp)nz&4P';            //Your database password
$db['db']       = 'riseofth_ocbc';   //Your database name
$db['prefix']   = '';            //Your table prefix, leave it empty


?>
