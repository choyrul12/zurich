<?php
$base_url = "http://localhost:81/briffest/";

/*admin*/
$session_name = "l61110lenovo";
$session_value = "Sayamalahbarutahukalaukopibubuksayainiberedardiinternet";
$admin_user = "zurich";
$admin_pass = "zurich";
$default_page = "user.php";

$admin_page_title = "The Rise Of Zurich Force";
$front_page_title = "The Rise Of Zurich Force";


$tts_box_size = "60px";
$tts_background = "transparent";
$tts_font_color = "#FFFFFF";

$api_key = "zurichapikey2018";
?>
